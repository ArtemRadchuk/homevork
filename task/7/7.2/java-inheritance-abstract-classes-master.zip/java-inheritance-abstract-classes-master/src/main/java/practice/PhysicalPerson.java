package practice;

public class PhysicalPerson extends Client {
}
