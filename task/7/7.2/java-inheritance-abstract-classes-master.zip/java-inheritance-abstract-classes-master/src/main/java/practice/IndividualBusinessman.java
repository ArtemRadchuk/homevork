package practice;

public class IndividualBusinessman extends Client {
}
