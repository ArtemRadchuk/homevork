package practice;

public class LegalPerson extends Client {
}
